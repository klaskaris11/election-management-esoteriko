from rest_framework.response import Response
from citizen.serializers import CitizenSerializer
from citizen.serializers import CitizenNewSerializer
from rest_framework.decorators import api_view
from rest_framework import status
from .models import Citizen
from django.http import JsonResponse
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import api_view, permission_classes


@api_view(['POST'])
@permission_classes((IsAuthenticated, ))
def citizen_create(request):
    if request.method == 'POST':
        serializer = CitizenNewSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['PUT'])
@permission_classes((IsAuthenticated, ))
def citizen_update(request, identity):
    number_of_identity = identity;
    cit = Citizen.objects.get(pk=number_of_identity)
    serializer = CitizenSerializer(cit, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@permission_classes((IsAuthenticated, ))
def citizen_list(request, identity):
    if request.method == 'GET':
        citizens_active = Citizen.objects.get(number_of_identity=identity).__dict__
        del citizens_active['_state']
        return JsonResponse(citizens_active, status=status.HTTP_200_OK)