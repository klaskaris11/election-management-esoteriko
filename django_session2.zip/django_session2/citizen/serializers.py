from django.contrib.auth.models import User, Group
from rest_framework import serializers
from .models import Citizen


class CitizenSerializer(serializers.ModelSerializer):
   class Meta:
       model = Citizen
       fields = ('firstname', 'lastname', 'email', 'address', 'addressnum', 'sex', 'phone_number', 'municipallity')


class CitizenNewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Citizen
        fields = ('firstname', 'lastname', 'email', 'date_of_birth', 'address', 'addressnum', 'sex', 'phone_number',
                  'municipallity', 'identitykind', 'number_of_identity', 'indentitydocument', 'bank', 'iban')


class GroupSerializer(serializers.HyperlinkedModelSerializer):
   class Meta:
       model = Group
       fields = ('url', 'name')