from django.contrib import admin
from citizen.models import Citizen

# Register your models here.
admin.site.register(Citizen)
