

from django.contrib import admin
from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from citizen import views
from rest_framework.authtoken.views import obtain_auth_token


urlpatterns = [
    path('register/', views.citizen_create),
    path('update/<identity>', views.citizen_update),
    path('<identity>', views.citizen_list),
    path('api-token-auth/', obtain_auth_token, name='api_token_auth'),

]


urlpatterns = format_suffix_patterns(urlpatterns)