from django_session2 import settings
from django.core.mail import send_mail
from django.db import models


# Create your models here.

class Citizen(models.Model):
    # Field name made lowercase.

    firstname = models.CharField(max_length=100, null=True)
    lastname = models.CharField(max_length=100, null=True)
    email = models.CharField(max_length=190, null=True)
    date_of_birth = models.DateField(null=True)
    address = models.CharField(max_length=80, null=True)
    addressnum = models.CharField(max_length=10, null=True)
    sex = models.CharField(max_length=15, null=True)
    phone_number = models.CharField(max_length=10, null=True)
    municipallity = models.CharField(max_length=100, null=True)
    identitykind = models.CharField(max_length=20, null=True)
    number_of_identity = models.CharField(max_length=15, null=False, primary_key=True)
    indentitydocument = models.CharField(max_length=256, null=True)
    bank = models.CharField(max_length=256, null=True)
    iban = models.CharField(max_length=256, null=True)
    status = models.IntegerField(default=0)
    vote_access = models.IntegerField(default=1)
    election = models.BooleanField(default=False)

    def __str__(self):
        return self.number_of_identity

    def save(self, *args, **kwargs):
        try:
            if self.number_of_identity:
                old_foo = Citizen.objects.get(pk=self.number_of_identity)
                if old_foo.election == False and self.election == True:
                    to_email = [old_foo.email]
                    from_email = settings.EMAIL_HOST_USER
                    send_mail('ΕΦΟΡΕΥΤΙΚΗ', 'ΕΧΕΤΕ ΕΠΙΛΕΧΤΕΙ ΓΙΑ ΕΦΟΡΕΥΤΙΚΗ ΕΠΙΤΡΟΠΗ', from_email, to_email,
                              fail_silently=False)
        except Citizen.DoesNotExist:
            pass
        super(Citizen, self).save(*args, **kwargs)